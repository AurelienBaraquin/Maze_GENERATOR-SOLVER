/*
** EPITECH PROJECT, 2023
** dante
** File description:
** main
*/

#include "my.h"

int gestion_error(int ac, char **av)
{
    if (ac != 3 && ac != 4)
        return 84;
    if (atoi(av[1]) == 0 || atoi(av[2]) == 0)
        return 84;
    if (ac == 4 && strcmp(av[3], "perfect") == 0)
        return 'p';
}

char ** create_array(int width, int height)
{
    char **array = malloc(sizeof(char *) * (height + 1));
    for (int i = 0; i < height; i++) {
        array[i] = malloc(sizeof(char) * (width + 1));
        for (int j = 0; j < width; j++) {
            if (i % 2 == 0 && j % 2 == 0)
                array[i][j] = mlrand(1, 9) + '0';
            else
                array[i][j] = 'X';
        }
        array[i][width] = '\0';
    }
    if (height % 2 == 0)
        for (int i = 0; i < width; i++)
            array[height - 1][i] = mlrand(1, 9) + '0';
    if (width % 2 == 0)
        for (int i = 0; i < height; i++)
            array[i][width - 1] = mlrand(1, 9) + '0';
    array[height] = NULL;
    return array;
}

void recursive_fill(char **maze, int x, int y, int height, char c)
{
    if (maze[y][x] == c)
        return;
    maze[y][x] = c;
    int limitx = strlen(maze[0]) - 1;
    int limity = height - 1;
    if (x < limitx)
        if (maze[y][x + 1] >= '0' && maze[y][x + 1] <= '9')
            recursive_fill(maze, x + 1, y, height, c);
    if (x > 0)
        if (maze[y][x - 1] >= '0' && maze[y][x - 1] <= '9')
            recursive_fill(maze, x - 1, y, height, c);
    if (y < limity)
        if (maze[y + 1][x] >= '0' && maze[y + 1][x] <= '9')
            recursive_fill(maze, x, y + 1, height, c);
    if (y > 0)
        if (maze[y - 1][x] >= '0' && maze[y - 1][x] <= '9')
            recursive_fill(maze, x, y - 1, height, c);
    return;
}

int verif_maze(char **maze, int width, int height)
{
    char nb = maze[0][0];
    for (int i = 0; i < height; i++)
        for (int j = 0; j < width; j++)
            if (maze[i][j] >= '0' && maze[i][j] <= '9' && maze[i][j] != nb)
                return 0;
    return 1;
}

void trace_maze(char **maze, int width, int height)
{
    if (verif_maze(maze, width, height) == 1)
        return;
    int x = mlrand(0, width - 1);
    int y = mlrand(0, height - 1);
    if (x % 2 == 1)
        x--;
    if (y % 2 == 1)
        y--;
    int dirx = mlrand(1, 4);
    int diry = 0;
    if (dirx >= 3) {
        dirx = 0;
        diry = mlrand(1, 2);
        if (diry == 2)
            diry = -1;
    } else if (dirx == 2)
        dirx = -1;
    if (x + dirx < 0 || x + dirx >= width || y + diry < 0 || y + diry >= height) {
        dirx = -dirx;
        diry = -diry;
    }
    if (maze[y + diry * 2][x + dirx * 2] != maze[y][x]) {
        maze[y + diry][x + dirx] = maze[y][x];
        recursive_fill(maze, x + dirx * 2, y + diry * 2, height, maze[y][x]);
    }
    trace_maze(maze, width, height);
}

void no_perfect(char **maze, int width, int height)
{
    int cb = (width * height) / 16;
    while (cb > 0) {
        int x = mlrand(0, width - 1);
        int y = mlrand(0, height - 1);
        if (maze[y][x] == 'X') {
            maze[y][x] = '*';
            cb--;
        }
    }
}

int main(int ac, char **av)
{
    int er = gestion_error(ac, av);
    int p = 0;
    if (er == 84)
        return 84;
    if (er == 'p')
        p = 1;
    int width = atoi(av[1]);
    int height = atoi(av[2]);
    if (width % 2 == 0)
        width++;
    if (height % 2 == 0)
        height++;
    char **maze = create_array(width, height);
    trace_maze(maze, width, height);
    if (p == 0)
        no_perfect(maze, width, height);
    int fd = open("maze.txt", O_CREAT | O_WRONLY | O_TRUNC, 0644);
    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {
            if (maze[i][j] != 'X')
                maze[i][j] = '*';
            write(1, &maze[i][j], 1);
        }
        write(1, "\n", 1);
    }
    return 0;
}