/*
** EPITECH PROJECT, 2023
** dante
** File description:
** my
*/

#ifndef my_H
    #define my_H

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

char **my_strtok_array(char *str, char *delim);
int mlrand(int min, int max);

#endif /* !my_H */
